import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editadm',
  templateUrl: './editadm.page.html',
  styleUrls: ['./editadm.page.scss'],
})
export class EditadmPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

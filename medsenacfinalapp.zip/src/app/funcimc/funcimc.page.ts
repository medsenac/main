import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-funcimc',
  templateUrl: './funcimc.page.html',
  styleUrls: ['./funcimc.page.scss'],
})
export class FuncimcPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

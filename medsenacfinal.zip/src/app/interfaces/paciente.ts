export interface Paciente {
    id?: string,
    name?: string,
    birthdate?: number,
    bloodtype?: string,
    height?: any,
    picture?:any,
    phone?: number,
    peso?: number,
    dataimc?: any,
    dataglicose?: number,
    pressaod?: number,
    pressaos?: number,
    datapam?: any  
    imc?: any;
    glicose?: any;
}

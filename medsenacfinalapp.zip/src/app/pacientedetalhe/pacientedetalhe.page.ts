import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pacientedetalhe',
  templateUrl: './pacientedetalhe.page.html',
  styleUrls: ['./pacientedetalhe.page.scss'],
})
export class PacientedetalhePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

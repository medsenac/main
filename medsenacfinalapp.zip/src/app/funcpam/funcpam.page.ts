import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-funcpam',
  templateUrl: './funcpam.page.html',
  styleUrls: ['./funcpam.page.scss'],
})
export class FuncpamPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editsujeito',
  templateUrl: './editsujeito.page.html',
  styleUrls: ['./editsujeito.page.scss'],
})
export class EditsujeitoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Pam } from './../interfaces/pam';
import { Paciente } from './../interfaces/paciente';
import { Injectable } from '@angular/core';
import { AngularFirestoreCollection, AngularFirestore } from '@angular/fire/firestore';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class PamService {

  
  private pamCollection: AngularFirestoreCollection<Pam>;
  constructor(private afs: AngularFirestore) {
    this.pamCollection = this.afs.collection<Pam>("Pam");
   }

   getPacientes(){ 
     //aqui serve para listar todos os pacientes cadastrados
     return this.pamCollection.snapshotChanges().pipe(
       map(actions =>{ 
        return actions.map(a =>{ 
          const data = a.payload.doc.data();
          const id = a.payload.doc.id;
          return {id, ...data};
        })
       })
     )
   }


   //adicionar Paciente
   addPam(pam: Pam){
    
    return this.pamCollection.add(pam);
  }
   getPam(id: string,){
     return this.pamCollection.doc<Pam>(id).valueChanges();
   }

   updatePam(id: string, pam: Pam){
     return this.pamCollection.doc<Pam>(id).update(pam);
   }

   deletePam(id: string){
     return this.pamCollection.doc(id).delete();
   }
}

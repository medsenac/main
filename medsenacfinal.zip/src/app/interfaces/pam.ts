export interface Pam {
    idpaciente?: String,
    pressaod?: any;
    pressaos?: any;
    datapam?: any;
    

}

export interface Paciente {
    id?: string,
    name?: string,
    birthdate?: number,
    bloodtype?: string,
    height?: string,
    picture?:any,
    phone?: any
}

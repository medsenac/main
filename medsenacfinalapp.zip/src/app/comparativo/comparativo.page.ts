import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comparativo',
  templateUrl: './comparativo.page.html',
  styleUrls: ['./comparativo.page.scss'],
})
export class ComparativoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

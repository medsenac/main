import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-funcglicose',
  templateUrl: './funcglicose.page.html',
  styleUrls: ['./funcglicose.page.scss'],
})
export class FuncglicosePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
